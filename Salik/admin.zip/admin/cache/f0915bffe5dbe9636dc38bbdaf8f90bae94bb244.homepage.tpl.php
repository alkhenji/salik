<?php /*%%SmartyHeaderCode:160295771e061802404-16070983%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'f0915bffe5dbe9636dc38bbdaf8f90bae94bb244' => 
    array (
      0 => 'F:\\Server\\wamp\\www\\Salik\\admin\\templates\\homepage.tpl',
      1 => 1466947361,
      2 => 'file',
    ),
    'c4f03d6001b6b922031cd996c9e9e57c311d1e35' => 
    array (
      0 => 'F:\\Server\\wamp\\www\\Salik\\admin\\templates\\header.tpl',
      1 => 1467006970,
      2 => 'file',
    ),
    'e7bb1d56d41cc8d652429860a6c4f73d2d7bde6f' => 
    array (
      0 => 'F:\\Server\\wamp\\www\\Salik\\admin\\templates\\nav.tpl',
      1 => 1467049823,
      2 => 'file',
    ),
    '43b1538c098d2addd845a984fa491dcab887ff0e' => 
    array (
      0 => 'F:\\Server\\wamp\\www\\Salik\\admin\\configs\\ads_en.conf',
      1 => 1335860188,
      2 => 'file',
    ),
    '772170e05b1b5afe98f53e29f2e092e53c76c439' => 
    array (
      0 => 'F:\\Server\\wamp\\www\\Salik\\admin\\templates\\footer.tpl',
      1 => 1467049768,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '160295771e061802404-16070983',
  'variables' => 
  array (
    'prefix' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.11',
  'unifunc' => 'content_5771e06199f154_65144903',
  'cache_lifetime' => 120,
),true); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5771e06199f154_65144903')) {function content_5771e06199f154_65144903($_smarty_tpl) {?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
	<title>ActionFigure</title>
	<link type="text/css" rel="stylesheet" href="css/style.css"/>
	
	 
	<link type="text/css" rel="stylesheet" href="css/ui-lightness/jquery-ui-1.8.23.custom.css" />
	<!--<link type="text/css" rel="stylesheet" href="css/jquery.ui.core.css" />
	<link type="text/css" rel="stylesheet" href="css/jquery.ui.theme.css" />!-->
	<link type="text/css" rel="stylesheet" href="css/jquery.ui.selectmenu.css" />
	<link type="text/css" rel="stylesheet" href="css/jquery.ui.tinytbl.css" />
<!--
    <link type="text/css" rel="stylesheet" href="css/ui.jqgrid.css" />
-->
	<script type="text/javascript" src="http://code.jquery.com/jquery-1.11.3.js"></script>
	<script type="text/javascript" src="js/jquery-1.8.0.min.js"></script>
	<script type="text/javascript" src="js/jquery-ui-1.8.23.custom.min.js"></script>
	
	
	<script type="text/javascript" src="js/jquery.ui.selectmenu.js"></script>
	<script type="text/javascript" src="js/jquery.ui.tinytbl.js"></script>
<!--
    <script type="text/javascript" src="js/grid.locale-en.js"></script>
    <script type="text/javascript" src="js/jquery.jqGrid.min.js"></script>
-->

	<!--[if IE 7]>
		<link rel="stylesheet" href="css/ie7.css" type="text/css" />
	<![endif]-->
	
</head>
<body id="dashboard" >
		
	<div class="page">
		<!-- Here Comes Page's Conetent!-->
		<div class="title">
		 	
		 	
		</div>
<!-- header -->
<div class="header">
	
	<ul>
		<li style="width:110px;" class="selected" >	<a href="./home.php">HOME</a></li>
		<li style="width:160px;"><a href="./drivers.php?times=1">DRIVERS</a></li>
		<li style="width:120px;"> <a href="./orders.php?times=1">ODERS</a></li>
        <li style="width:100px;"> <a href="./car.php?times=1">CARS</a></li>
                
        <li style="width:130px;"> <a href="./logout.php">LOGOUT</a></li>
			
	</ul>
</div>
<!-- content -->

<div class="body">
    <div class="featured">
    <h1>SALIK ADMIN</h1>
    </div>
   					
	</div>
</div>
		<div class="footer">
				<ul>
				
					<li ><a href="home.php">HOME</a></li>
					<li><a href="drivers.php?times=1">DRIVERS</a></li>
					<li> <a href="orders.php?times=1">ODERS</a></li>
					<li> <a href="car.php?times=1">CARS</a></li>
							
					<li> <a href="logout.php">LOGOUT</a></li>
					
				</ul>
				</br>
				</br>
				<p>&#169; Copyright &#169; 2016.</p>
			</div>
		</div>
	</body>
</html>  

<?php }} ?>