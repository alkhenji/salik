<?php /*%%SmartyHeaderCode:93015771e06a403e04-95777711%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '15879d6e349805f13a7488dfd2e2e7bd23e6a88d' => 
    array (
      0 => 'F:\\Server\\wamp\\www\\Salik\\admin\\templates\\orders.tpl',
      1 => 1467050065,
      2 => 'file',
    ),
    'c4f03d6001b6b922031cd996c9e9e57c311d1e35' => 
    array (
      0 => 'F:\\Server\\wamp\\www\\Salik\\admin\\templates\\header.tpl',
      1 => 1467006970,
      2 => 'file',
    ),
    'e7bb1d56d41cc8d652429860a6c4f73d2d7bde6f' => 
    array (
      0 => 'F:\\Server\\wamp\\www\\Salik\\admin\\templates\\nav.tpl',
      1 => 1467049823,
      2 => 'file',
    ),
    '43b1538c098d2addd845a984fa491dcab887ff0e' => 
    array (
      0 => 'F:\\Server\\wamp\\www\\Salik\\admin\\configs\\ads_en.conf',
      1 => 1335860188,
      2 => 'file',
    ),
    '772170e05b1b5afe98f53e29f2e092e53c76c439' => 
    array (
      0 => 'F:\\Server\\wamp\\www\\Salik\\admin\\templates\\footer.tpl',
      1 => 1467049768,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '93015771e06a403e04-95777711',
  'variables' => 
  array (
    'prefix' => 0,
    'totalOrderNumber' => 0,
    'totalPendingNumber' => 0,
    'totalInprogressNumber' => 0,
    'totalCancelledNumber' => 0,
    'totalCompletedNumber' => 0,
    'orders' => 0,
    'data' => 0,
    'times' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.11',
  'unifunc' => 'content_5771e06a63d253_91888178',
  'cache_lifetime' => 120,
),true); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5771e06a63d253_91888178')) {function content_5771e06a63d253_91888178($_smarty_tpl) {?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
	<title>ActionFigure</title>
	<link type="text/css" rel="stylesheet" href="css/style.css"/>
	
	 
	<link type="text/css" rel="stylesheet" href="css/ui-lightness/jquery-ui-1.8.23.custom.css" />
	<!--<link type="text/css" rel="stylesheet" href="css/jquery.ui.core.css" />
	<link type="text/css" rel="stylesheet" href="css/jquery.ui.theme.css" />!-->
	<link type="text/css" rel="stylesheet" href="css/jquery.ui.selectmenu.css" />
	<link type="text/css" rel="stylesheet" href="css/jquery.ui.tinytbl.css" />
<!--
    <link type="text/css" rel="stylesheet" href="css/ui.jqgrid.css" />
-->
	<script type="text/javascript" src="http://code.jquery.com/jquery-1.11.3.js"></script>
	<script type="text/javascript" src="js/jquery-1.8.0.min.js"></script>
	<script type="text/javascript" src="js/jquery-ui-1.8.23.custom.min.js"></script>
	
	
	<script type="text/javascript" src="js/jquery.ui.selectmenu.js"></script>
	<script type="text/javascript" src="js/jquery.ui.tinytbl.js"></script>
<!--
    <script type="text/javascript" src="js/grid.locale-en.js"></script>
    <script type="text/javascript" src="js/jquery.jqGrid.min.js"></script>
-->

	<!--[if IE 7]>
		<link rel="stylesheet" href="css/ie7.css" type="text/css" />
	<![endif]-->
	
</head>
<body id="dashboard" >
		
	<div class="page">
		<!-- Here Comes Page's Conetent!-->
		<div class="title">
		 	
		 	
		</div>
<!-- header -->
<div class="header">
	
	<ul>
		<li style="width:110px;">	<a href="./home.php">HOME</a></li>
		<li style="width:160px;"><a href="./drivers.php?times=1">DRIVERS</a></li>
		<li style="width:120px;" class="selected" > <a href="./orders.php?times=1">ODERS</a></li>
        <li style="width:100px;"> <a href="./car.php?times=1">CARS</a></li>
                
        <li style="width:130px;"> <a href="./logout.php">LOGOUT</a></li>
			
	</ul>
</div>
<script>

	function orderEdit(id,times){
            
            var x = document.getElementById(id).value;
           
		     if(confirm("Are you sure you want to change this order?") == true){
			location.href="orders.php?action=edit&order_id="+id+"&times="+times+"&order_state="+x;
		    }else{
			return;
		}
	}
	
	function viewMore(times){
		    times++;
			location.href="orders.php?times="+times;
		
	}
  
      
	function driverDelete(id,times){
		 if(confirm("Are you sure you want to delete this driver?") == true){
			location.href="drivers.php?action=driver_delete&driver_id="+id+"&times="+times;
		}else{
			return;
		}
	}
</script>
<div class="body">
</br>
	<h2 class="heading2">Summary of Orders</h2>
	<div id="div_seperate" class="div_seperate"></div>
	<div id="div_order_edit" class="div_order_edit">
        <ul >
            <li ><h2>6</h2><h3>Orders</h3></li>
            <li><h2>0</h2><h3>Pending</h3></li>
            <li ><h2>1</h2><h3>Inprogress</h3></li>
            <li ><h2>2</h2><h3>Cancelled</h3></li>
            <li ><h2>3</h2><h3>Completed</h3></li>

		</ul>
       
	</div>
   
	<h2 class="heading2">Orders Data</h2>
	<div id="div_seperate" class="div_seperate"></div>
		
		<div id="div_tbl_user" class="div_tbl_user" style="margin:0 auto;">

			<table id="users" class="stats" border="1" border-spacing="1px"  >
					<tbody style="width:100%;">
					<tr class="statshead" style="width:100%;">
						<td style="width:22%;">
							Date/Time
						</td>
						<td style="width:22%;">
							Client#
						</td>
                        
						 <td style="width:22%;">
							Driver ID
						</td>
						<td style="width:22%;">
							Status
						</td>
						                      
                       
						<td style="width:12%;">
							Modify
						</td>
						
												
											
					</tr>
											<tr class="statsrow">
                        	<td>
								2016-06-14 06:08:08
							</td>
							<td>
								2
							</td>
							<td>
								0
							</td>
							<td><select id="2" class="status" >
                                    <option value="1" Selected>
                                          Inprogress                                                                                                                                                                  
                                        </option>
                                    <option value='1'>Inprogress</option>
                                    <option value='2'>Pending</option>
                                    <option value='3'>Completed</option>	
                                    <option value='4'>Cancelled</option>						
                                    					
                                </select>
							</td>
							
							<td>
							<div class="modifyDiv">
								<ul >
									<li ><a href="javascript: orderEdit(2,1);"class="view">edit</a></li>
									
																
								</ul>
							</div>
								
							</td>
							
							
							
						</tr>
											<tr class="statsrow">
                        	<td>
								2016-06-14 06:14:22
							</td>
							<td>
								7
							</td>
							<td>
								0
							</td>
							<td><select id="7" class="status" disabled  >
                                    <option value="3" Selected>
                                                                                                                          Completed                                                                                  
                                        </option>
                                    <option value='1'>Inprogress</option>
                                    <option value='2'>Pending</option>
                                    <option value='3'>Completed</option>	
                                    <option value='4'>Cancelled</option>						
                                    					
                                </select>
							</td>
							
							<td>
							<div class="modifyDiv">
								<ul >
									<li ><a href="javascript: orderEdit(7,1);"class="view"> - </a></li>
									
																
								</ul>
							</div>
								
							</td>
							
							
							
						</tr>
											<tr class="statsrow">
                        	<td>
								2016-06-14 04:35:55
							</td>
							<td>
								1
							</td>
							<td>
								0
							</td>
							<td><select id="1" class="status" disabled  >
                                    <option value="4" Selected>
                                                                                                                                                                  Cancelled                                          
                                        </option>
                                    <option value='1'>Inprogress</option>
                                    <option value='2'>Pending</option>
                                    <option value='3'>Completed</option>	
                                    <option value='4'>Cancelled</option>						
                                    					
                                </select>
							</td>
							
							<td>
							<div class="modifyDiv">
								<ul >
									<li ><a href="javascript: orderEdit(1,1);"class="view"> - </a></li>
									
																
								</ul>
							</div>
								
							</td>
							
							
							
						</tr>
										</tbody>
						
				</table>
				<div style="width:120px;margin:0 auto;">
				 	<a href="javascript:viewMore(1);"class="view">View More</a>
				</div>
				</br>
		</div>
	
</div>
</div>

		<div class="footer">
				<ul>
				
					<li ><a href="home.php">HOME</a></li>
					<li><a href="drivers.php?times=1">DRIVERS</a></li>
					<li> <a href="orders.php?times=1">ODERS</a></li>
					<li> <a href="car.php?times=1">CARS</a></li>
							
					<li> <a href="logout.php">LOGOUT</a></li>
					
				</ul>
				</br>
				</br>
				<p>&#169; Copyright &#169; 2016.</p>
			</div>
		</div>
	</body>
</html>  

<?php }} ?>