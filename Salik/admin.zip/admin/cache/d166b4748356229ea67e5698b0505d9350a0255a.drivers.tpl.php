<?php /*%%SmartyHeaderCode:101375771e0696613c5-76805872%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'd166b4748356229ea67e5698b0505d9350a0255a' => 
    array (
      0 => 'F:\\Server\\wamp\\www\\Salik\\admin\\templates\\drivers.tpl',
      1 => 1467050800,
      2 => 'file',
    ),
    'c4f03d6001b6b922031cd996c9e9e57c311d1e35' => 
    array (
      0 => 'F:\\Server\\wamp\\www\\Salik\\admin\\templates\\header.tpl',
      1 => 1467006970,
      2 => 'file',
    ),
    'e7bb1d56d41cc8d652429860a6c4f73d2d7bde6f' => 
    array (
      0 => 'F:\\Server\\wamp\\www\\Salik\\admin\\templates\\nav.tpl',
      1 => 1467049823,
      2 => 'file',
    ),
    '43b1538c098d2addd845a984fa491dcab887ff0e' => 
    array (
      0 => 'F:\\Server\\wamp\\www\\Salik\\admin\\configs\\ads_en.conf',
      1 => 1335860188,
      2 => 'file',
    ),
    '772170e05b1b5afe98f53e29f2e092e53c76c439' => 
    array (
      0 => 'F:\\Server\\wamp\\www\\Salik\\admin\\templates\\footer.tpl',
      1 => 1467049768,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '101375771e0696613c5-76805872',
  'variables' => 
  array (
    'prefix' => 0,
    'driver_id' => 0,
    'times' => 0,
    'mode' => 0,
    'fullname' => 0,
    'username' => 0,
    'password' => 0,
    'totalDriversNumber' => 0,
    'drivers' => 0,
    'data' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.11',
  'unifunc' => 'content_5771e069876735_45741915',
  'cache_lifetime' => 120,
),true); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5771e069876735_45741915')) {function content_5771e069876735_45741915($_smarty_tpl) {?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
	<title>ActionFigure</title>
	<link type="text/css" rel="stylesheet" href="css/style.css"/>
	
	 
	<link type="text/css" rel="stylesheet" href="css/ui-lightness/jquery-ui-1.8.23.custom.css" />
	<!--<link type="text/css" rel="stylesheet" href="css/jquery.ui.core.css" />
	<link type="text/css" rel="stylesheet" href="css/jquery.ui.theme.css" />!-->
	<link type="text/css" rel="stylesheet" href="css/jquery.ui.selectmenu.css" />
	<link type="text/css" rel="stylesheet" href="css/jquery.ui.tinytbl.css" />
<!--
    <link type="text/css" rel="stylesheet" href="css/ui.jqgrid.css" />
-->
	<script type="text/javascript" src="http://code.jquery.com/jquery-1.11.3.js"></script>
	<script type="text/javascript" src="js/jquery-1.8.0.min.js"></script>
	<script type="text/javascript" src="js/jquery-ui-1.8.23.custom.min.js"></script>
	
	
	<script type="text/javascript" src="js/jquery.ui.selectmenu.js"></script>
	<script type="text/javascript" src="js/jquery.ui.tinytbl.js"></script>
<!--
    <script type="text/javascript" src="js/grid.locale-en.js"></script>
    <script type="text/javascript" src="js/jquery.jqGrid.min.js"></script>
-->

	<!--[if IE 7]>
		<link rel="stylesheet" href="css/ie7.css" type="text/css" />
	<![endif]-->
	
</head>
<body id="dashboard" >
		
	<div class="page">
		<!-- Here Comes Page's Conetent!-->
		<div class="title">
		 	
		 	
		</div>
<!-- header -->
<div class="header">
	
	<ul>
		<li style="width:110px;">	<a href="./home.php">HOME</a></li>
		<li style="width:160px;" class="selected" ><a href="./drivers.php?times=1">DRIVERS</a></li>
		<li style="width:120px;"> <a href="./orders.php?times=1">ODERS</a></li>
        <li style="width:100px;"> <a href="./car.php?times=1">CARS</a></li>
                
        <li style="width:130px;"> <a href="./logout.php">LOGOUT</a></li>
			
	</ul>
</div>
<script>

	function driverEdit(id,times){
		     
			location.href="drivers.php?action=mode&driver_id="+id+"&times="+times;
		
	}
	
	function viewMore(times){
		    times++;
			location.href="drivers.php?times="+times;
		
	}
   
      
	function driverDelete(id,times){
		 if(confirm("Are you sure you want to delete this driver?") == true){
			location.href="drivers.php?action=driver_delete&driver_id="+id+"&times="+times;
		}else{
			return;
		}
	}
</script>
<div class="body">
</br>
	<h2 class="heading2">edit drivers</h2>
	<div id="div_seperate" class="div_seperate"></div>
	<div id="div_user_edit" class="user_edit">
	
		<div class="div_form">
			<form action="drivers.php?action=driver_info&driver_id=&times=1" name="driver_info_form" id="driver_info_form"  method="post" enctype="multipart/form-data"autocomplete="off" >
				<input type="hidden"name="mode"value="Add"/>
				<p style="margin-left:20px;">
				Name:<input type="text" id="fullname" name="fullname" value="" class="input_data" style="margin-right:20px;"placeholder="Enter FullName"/>
				Username:<input type="text" id="username1" name="username" value="" class="input_data" placeholder="Enter Username" />
						
				Password:<input type="password" id="password1" name="password" value="" class="input_data" placeholder="Enter Password:*********"/>
				<input id="btnsave" type="submit" class="submit" value="Add"/>
				
				
				</p>
			</form>
		</div>	
	</div>
	<h2 class="heading2">Drivers Data</h2>
	<div id="div_seperate" class="div_seperate"></div>
		
		<div id="div_tbl_user" class="div_tbl_user" style="margin:0 auto;">

			<h2 style="margin-left:1350px;margin-bottom:-15px;color:#ffffff;">Number of Drivers : 17</h2>
			<table id="users" class="stats" border="1" border-spacing="1px"  >
					<tbody style="width:100%;">
					<tr class="statshead" style="width:100%;">
						<td style="width:18%;">
							Name
						</td>
						<td style="width:18%;">
							ID#
						</td>
                        
						 <td style="width:18%;">
							Car ID#
						</td>
						<td style="width:18%;">
							Username
						</td>
						<td style="width:18%;">
							Password
						</td>
                       
                       
						<td style="width:10%;">
							Modify
						</td>
						
												
											
					</tr>
											<tr class="statsrow">
                        	<td>
								test
							</td>
							<td>
								
							</td>
							<td>
								102340340
							</td>
							<td>
								zhuchen
							</td>
							
							<td>
								zhuchen
							</td>
                            
                            
							<td>
							<div class="modifyDiv">
								<ul >
									<li ><a href="javascript: driverEdit(7,1);"class="view">edit</a></li>|
									
									<li><a href="javascript:driverDelete(7,1);"class="view">delete</a></li>
								
								</ul>
							</div>
								
							</td>
							
							
							
						</tr>
											<tr class="statsrow">
                        	<td>
								testdriver2
							</td>
							<td>
								390175
							</td>
							<td>
								102340340
							</td>
							<td>
								testusername
							</td>
							
							<td>
								admin
							</td>
                            
                            
							<td>
							<div class="modifyDiv">
								<ul >
									<li ><a href="javascript: driverEdit(13,1);"class="view">edit</a></li>|
									
									<li><a href="javascript:driverDelete(13,1);"class="view">delete</a></li>
								
								</ul>
							</div>
								
							</td>
							
							
							
						</tr>
											<tr class="statsrow">
                        	<td>
								testtest
							</td>
							<td>
								906649110
							</td>
							<td>
								102340340
							</td>
							<td>
								testusername2
							</td>
							
							<td>
								testusername2
							</td>
                            
                            
							<td>
							<div class="modifyDiv">
								<ul >
									<li ><a href="javascript: driverEdit(15,1);"class="view">edit</a></li>|
									
									<li><a href="javascript:driverDelete(15,1);"class="view">delete</a></li>
								
								</ul>
							</div>
								
							</td>
							
							
							
						</tr>
										</tbody>
						
				</table>
				<div style="width:120px;margin:0 auto;">
				 	<a href="javascript:viewMore(1);"class="view">View More</a>
				</div>
				</br>
		</div>
	
</div>
</div>
		<div class="footer">
				<ul>
				
					<li ><a href="home.php">HOME</a></li>
					<li><a href="drivers.php?times=1">DRIVERS</a></li>
					<li> <a href="orders.php?times=1">ODERS</a></li>
					<li> <a href="car.php?times=1">CARS</a></li>
							
					<li> <a href="logout.php">LOGOUT</a></li>
					
				</ul>
				</br>
				</br>
				<p>&#169; Copyright &#169; 2016.</p>
			</div>
		</div>
	</body>
</html>  

<?php }} ?>