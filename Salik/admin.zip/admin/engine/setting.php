<?php

// Database Setting Parameters
define("DB_HOST", "localhost");
define("DB_NAME", "salikdb");
define("DB_USER", "root");
define("DB_PASSWORD", "");

// Language settings
$smarty->assign('sitelang', $sitelang);

// Site prefix
$prefix = "";
$smarty->assign('prefix', $prefix);

	
// Mail settings
//define("SMTP_HOST", 			"smtp.live.com");
//define("SMTP_USERNAME", 		"incrediboy1012@hotmail.com");
//define("SMTP_PASSWORD", 		"xxxxxxxx");
//define("DEFAULT_MAIL_ADDRESS", 	"incrediboy1012@hotmail.com");
//define("SMTP_AUTH", 			true);

?>
