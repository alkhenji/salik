
$times=1;
<?php
 /**
 * index.php, home page.
 * @package Example-application
 */

require('./setup.php');


require_once('dbDriver.php');
$action="";
$driver=null;

$driver_fullname="";
$driver_username="";
$driver_password="";
$driver_id="";
$driver_number_id="";
$mode="Add";

if(isset($_REQUEST['action']))
{
    $action = $_REQUEST['action'];
}
if (isset($_SESSION['loggedin']) && $_SESSION['loggedin'] == true) {
	$times=$_REQUEST['times'];
if($action == "driver_info") //create new app
{
    //$user_id=$_REQUEST['id'];
	$driver_username=$_REQUEST['username'];
	$driver_fullname=$_REQUEST['fullname'];
	$driver_password=$_REQUEST['password'];
	$driver_number_id=mt_rand(100000000, 999999999);
	$mode=$_REQUEST['mode'];
    
	 if($mode=='Add'){
		 if($dbDriver->checkDrivername($driver_username)){
			echo "<script>alert('Invalid username ')</script>";
		}else{
				$dbDriver->createDriver( $driver_fullname,$driver_username,$driver_password,$driver_number_id);
				$driver_fullname="";
				$driver_username="";
				$driver_password="";
		}
	}

	if($mode=='Save'){
		$driver_id=$_REQUEST['driver_id'];
        $driver=$dbDriver->getDriverById($driver_id);
		$dbDriver->saveDriverById($driver_id,$driver_fullname,$driver_username,$driver_password);
		$mode="Add";
		$driver_fullname="";
		$driver_username="";
		$driver_password="";
		  
	}
}			
if($action=="mode"){
	$driver_id=$_REQUEST['driver_id'];
	$driver=$dbDriver->getDriverById($driver_id);
    $driver_username=$driver['driver_name'];
	$driver_fullname=$driver['driver_fullname'];
	$driver_password=$driver['driver_password'];
    $mode="Save";
}
if($action=="driver_delete"){
	$driver_id=$_REQUEST['driver_id'];
	$dbDriver->dropDriverByID($driver_id);
}
	
	$drivers=$dbDriver->getDrivers($times);
	$totalDriversNumber=$dbDriver->getTotalDriversNumber();
   $smarty->assign('totalDriversNumber',$totalDriversNumber);
	$smarty->assign('driver_id',$driver_id);
	$smarty->assign('fullname',$driver_fullname);
	$smarty->assign('username',$driver_username);
	$smarty->assign('password',$driver_password);
	$smarty->assign('drivers',$drivers);
	$smarty->assign('times',$times);
   	$smarty->assign('mode',$mode);
	$smarty->display("{$prefix}drivers.tpl");
}else{
    $smarty->display("login.tpl");
}
?>