<?php /* Smarty version Smarty-3.1.11, created on 2016-06-28 04:16:37
         compiled from "F:\Server\wamp\www\admin\templates\footer.tpl" */ ?>
<?php /*%%SmartyHeaderCode:116595771de05451006-02855092%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'a1be52e223c03dd7ff232ffce4edae6749b97fc9' => 
    array (
      0 => 'F:\\Server\\wamp\\www\\admin\\templates\\footer.tpl',
      1 => 1467049768,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '116595771de05451006-02855092',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.11',
  'unifunc' => 'content_5771de05452d36_27875679',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5771de05452d36_27875679')) {function content_5771de05452d36_27875679($_smarty_tpl) {?>		<div class="footer">
				<ul>
				
					<li ><a href="home.php">HOME</a></li>
					<li><a href="drivers.php?times=1">DRIVERS</a></li>
					<li> <a href="orders.php?times=1">ODERS</a></li>
					<li> <a href="car.php?times=1">CARS</a></li>
							
					<li> <a href="logout.php">LOGOUT</a></li>
					
				</ul>
				</br>
				</br>
				<p>&#169; Copyright &#169; 2016.</p>
			</div>
		</div>
	</body>
</html>  <?php }} ?>