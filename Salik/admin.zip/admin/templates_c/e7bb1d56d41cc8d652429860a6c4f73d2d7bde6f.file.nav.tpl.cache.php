<?php /* Smarty version Smarty-3.1.11, created on 2016-06-28 04:26:51
         compiled from "F:\Server\wamp\www\Salik\admin\templates\nav.tpl" */ ?>
<?php /*%%SmartyHeaderCode:220715771e06b377018-71651432%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'e7bb1d56d41cc8d652429860a6c4f73d2d7bde6f' => 
    array (
      0 => 'F:\\Server\\wamp\\www\\Salik\\admin\\templates\\nav.tpl',
      1 => 1467049823,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '220715771e06b377018-71651432',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'currentnav' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.11',
  'unifunc' => 'content_5771e06b3aaa19_90044841',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5771e06b3aaa19_90044841')) {function content_5771e06b3aaa19_90044841($_smarty_tpl) {?><!-- header -->
<div class="header">
	
	<ul>
		<li style="width:110px;"<?php if ($_smarty_tpl->tpl_vars['currentnav']->value=="homepage"){?> class="selected" <?php }?>>	<a href="./home.php">HOME</a></li>
		<li style="width:160px;"<?php if ($_smarty_tpl->tpl_vars['currentnav']->value=="users"){?> class="selected" <?php }?>><a href="./drivers.php?times=1">DRIVERS</a></li>
		<li style="width:120px;"<?php if ($_smarty_tpl->tpl_vars['currentnav']->value=="orders"){?> class="selected" <?php }?>> <a href="./orders.php?times=1">ODERS</a></li>
        <li style="width:100px;"<?php if ($_smarty_tpl->tpl_vars['currentnav']->value=="cars"){?> class="selected" <?php }?>> <a href="./car.php?times=1">CARS</a></li>
                
        <li style="width:130px;"<?php if ($_smarty_tpl->tpl_vars['currentnav']->value=="logout"){?> class="selected" <?php }?>> <a href="./logout.php">LOGOUT</a></li>
			
	</ul>
</div><?php }} ?>