<?php $_config_vars = array (
  'sections' => 
  array (
    'news' => 
    array (
      'vars' => 
      array (
      ),
    ),
  ),
  'vars' => 
  array (
    'dateformat' => '%Y-%m-%d',
  ),
); ?>