function clearField(id) {
   if(document.getElementById) {
      document.getElementById(id).reset();
   }
}