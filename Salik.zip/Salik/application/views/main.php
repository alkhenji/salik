<div class="container-wrapper">
	<div class="container">
	
		<h1><center>Welcome to Salik</center></h1>

    </div>
</div>
<div class="be-clear"></div>

<?php
/* 
$data = array();


$data[] = array(
	"post_id"=>1, "post_user_id"=>1, "post_user_name"=>"EmAmbrose", "post_approved"=>1,
	"post_photo_url"=>"ls_media_post_post_01_01@2x.png", "post_photo_thumb_url"=>"ls_media_post_post_01_01@2x.png", "post_date"=>"2015-07-10 12:30:15",
	"post_item_ids"=>",1,2,3,"
);

$data[] = array(
	"post_id"=>2, "post_user_id"=>1, "post_user_name"=>"EmAmbrose", "post_approved"=>1,
	"post_photo_url"=>"ls_media_post_post_01_02@2x.png", "post_photo_thumb_url"=>"ls_media_post_post_01_02@2x.png", "post_date"=>"2015-07-13 14:30:15",
	"post_item_ids"=>",4,5,6,"
);


$data[] = array(
	"post_id"=>3, "post_user_id"=>1, "post_user_name"=>"EmAmbrose", "post_approved"=>1,
	"post_photo_url"=>"ls_media_post_post_01_03@2x.png", "post_photo_thumb_url"=>"ls_media_post_post_01_03@2x.png", "post_date"=>"2015-07-12 19:33:35",
	"post_item_ids"=>",7,8,9,"
);


$data[] = array(
	"post_id"=>4, "post_user_id"=>1, "post_user_name"=>"EmAmbrose", "post_approved"=>1,
	"post_photo_url"=>"ls_media_post_post_01_04@2x.png", "post_photo_thumb_url"=>"ls_media_post_post_01_04@2x.png", "post_date"=>"2015-07-13 10:30:15",
	"post_item_ids"=>",10,11,12,"
);


$data[] = array(
	"post_id"=>5, "post_user_id"=>1, "post_user_name"=>"EmAmbrose", "post_approved"=>1,
	"post_photo_url"=>"ls_media_post_post_01_05@2x.png", "post_photo_thumb_url"=>"ls_media_post_post_01_05@2x.png", "post_date"=>"2015-07-13 13:33:15",
	"post_item_ids"=>",13,14,15,16,"
);


$data[] = array(
	"post_id"=>6, "post_user_id"=>4, "post_user_name"=>"LeyLey", "post_approved"=>1,
	"post_photo_url"=>"ls_media_post_post_05_01@2x.png", "post_photo_thumb_url"=>"ls_media_post_post_05_01@2x.png", "post_date"=>"2015-07-12 16:28:10",
	"post_item_ids"=>",17,18,19,"
);


$data[] = array(
	"post_id"=>7, "post_user_id"=>4, "post_user_name"=>"LeyLey", "post_approved"=>1,
	"post_photo_url"=>"ls_media_post_post_05_02@2x.png", "post_photo_thumb_url"=>"ls_media_post_post_05_02@2x.png", "post_date"=>"2015-07-12 11:29:15",
	"post_item_ids"=>",20,21,22,"
);


$data[] = array(
	"post_id"=>8, "post_user_id"=>4, "post_user_name"=>"LeyLey", "post_approved"=>1,
	"post_photo_url"=>"ls_media_post_post_05_03@2x.png", "post_photo_thumb_url"=>"ls_media_post_post_05_03@2x.png", "post_date"=>"2015-07-13 10:57:15",
	"post_item_ids"=>",23,24,25,"
);


$data[] = array(
	"post_id"=>9, "post_user_id"=>4, "post_user_name"=>"LeyLey", "post_approved"=>1,
	"post_photo_url"=>"ls_media_post_post_05_04@2x.png", "post_photo_thumb_url"=>"ls_media_post_post_05_04@2x.png", "post_date"=>"2015-07-11 09:38:15",
	"post_item_ids"=>",26,27,28,"
);


$data[] = array(
	"post_id"=>10, "post_user_id"=>4, "post_user_name"=>"LeyLey", "post_approved"=>1,
	"post_photo_url"=>"ls_media_post_post_05_05@2x.png", "post_photo_thumb_url"=>"ls_media_post_post_05_05@2x.png", "post_date"=>"2015-07-15 07:32:15",
	"post_item_ids"=>",29,30,31,"
);
	
foreach($data as $item) {
	$this->db->insert('ls_posts', $item);
}
 */
?>